//
//  WorkoutListCell.swift
//  ChungSungChungSung
//
//  Created by Eunbee Kang on 2022/08/10.
//

import Foundation
import UIKit

class WorkoutListCell: UITableViewCell {
    @IBOutlet weak var workoutTitle: UILabel!
}
