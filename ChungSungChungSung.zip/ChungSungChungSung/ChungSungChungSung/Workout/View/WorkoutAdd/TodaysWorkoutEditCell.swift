//
//  TodaysWorkoutEditCell.swift
//  ChungSungChungSung
//
//  Created by Eunbee Kang on 2022/08/11.
//

import UIKit

class TodaysWorkoutEditCell: UITableViewCell {
    @IBOutlet weak var todaysWorkoutTitle: UILabel!
    
}
