//
//  WorkoutTodayCell.swift
//  ChungSungChungSung
//
//  Created by Eunbee Kang on 2022/08/09.
//

import UIKit

class TodaysWorkoutCell: UITableViewCell {
    @IBOutlet weak var todayWorkoutTitle: UILabel!
    
}
